export function init() {
    const guessInput = document.getElementById('guess');
    const guessButton = document.getElementById('guessButton');
    const feedback = document.getElementById('feedback');
    const scoreBoard = document.querySelector('.score-board');
    const gameOver = document.querySelector('.game-over');
    const resetButton = document.querySelector('.reset-button');
    const finalScore = document.querySelector('.final-score');

    let targetNumber = Math.floor(Math.random() * 100) + 1;
    let attempts = 0;
    let maxAttempts = 10;

    function setupGame() {
        targetNumber = Math.floor(Math.random() * 100) + 1;
        attempts = 0;
        updateScore();
        feedback.textContent = '';
        guessInput.value = '';
        guessInput.disabled = false;
        guessButton.disabled = false;
        guessInput.focus();
    }

    function handleGuess() {
        const guess = parseInt(guessInput.value);
        
        if (isNaN(guess) || guess < 1 || guess > 100) {
            feedback.textContent = 'Please enter a number between 1 and 100';
            return;
        }

        attempts++;
        updateScore();

        if (guess === targetNumber) {
            feedback.textContent = `Correct! The number was ${targetNumber}`;
            feedback.style.color = 'var(--primary-color)';
            
            // Play win sound
            const winSound = new Howl({
                src: ['sounds/win.mp3']
            });
            winSound.play();
            
            gameOverGame();
        } else if (attempts >= maxAttempts) {
            feedback.textContent = `Game Over! The number was ${targetNumber}`;
            feedback.style.color = 'var(--secondary-color)';
            
            // Play game over sound
            const gameOverSound = new Howl({
                src: ['sounds/gameover.mp3']
            });
            gameOverSound.play();
            
            gameOverGame();
        } else {
            const hint = guess > targetNumber ? 'Too High!' : 'Too Low!';
            feedback.textContent = hint;
            feedback.style.color = guess > targetNumber ? 'var(--secondary-color)' : 'var(--primary-color)';
            
            // Play hint sound
            const hintSound = new Howl({
                src: ['sounds/hint.mp3']
            });
            hintSound.play();
            // Add hint system
            if (Math.abs(guess - targetNumber) <= 5 && guess !== targetNumber) {
                feedback.textContent += ' (Very close!)';
            }
        }
    }

    function updateScore() {
        scoreBoard.textContent = `Attempts: ${attempts}/${maxAttempts}`;
        finalScore.textContent = attempts;
    }

    function gameOverGame() {
        guessInput.disabled = true;
        guessButton.disabled = true;
        gameOver.classList.add('visible');
    }

    // Event listeners
    guessButton.addEventListener('click', handleGuess);
    guessInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleGuess();
        }
    });

    resetButton.addEventListener('click', () => {
        setupGame();
    });

    // Initialize game
    setupGame();
}
