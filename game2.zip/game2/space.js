export function init() {
    const canvas = document.querySelector('canvas');
    const ctx = canvas.getContext('2d');
    const gameControls = document.querySelector('.game-controls');
    const scoreBoard = document.querySelector('.score-board');
    const gameOver = document.querySelector('.game-over');

    const player = {
        x: canvas.width / 2,
        y: canvas.height - 30,
        width: 50,
        height: 30,
        speed: 5
    };

    const bullets = [];
    const enemies = [];
    let score = 0;
    let gameActive = true;

    function draw() {
        if (!gameActive) return;

        // Clear canvas
        ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw player
        ctx.fillStyle = '#4CAF50';
        ctx.fillRect(player.x - player.width/2, player.y, player.width, player.height);

        // Draw bullets
        bullets.forEach((bullet, index) => {
            bullet.y -= 5;
            ctx.fillStyle = '#ff4444';
            ctx.fillRect(bullet.x, bullet.y, 5, 10);

            // Remove bullets that go off screen
            if (bullet.y < 0) {
                bullets.splice(index, 1);
            }

            // Check for enemy collisions
            enemies.forEach((enemy, enemyIndex) => {
                if (bullet.x > enemy.x && bullet.x < enemy.x + enemy.width && 
                    bullet.y > enemy.y && bullet.y < enemy.y + enemy.height) {
                    enemies.splice(enemyIndex, 1);
                    bullets.splice(index, 1);
                    score += 10;
                    updateScore();
                    
                    // Play hit sound
                    const hitSound = new Howl({
                        src: ['sounds/hit.mp3']
                    });
                    hitSound.play();
                }
            });
        });

        // Draw enemies
        enemies.forEach((enemy, index) => {
            enemy.y += enemy.speed;
            ctx.fillStyle = '#ff4444';
            ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);

            // Check for enemy collision with player
            if (enemy.y + enemy.height > player.y && 
                enemy.x < player.x + player.width/2 && 
                enemy.x + enemy.width > player.x - player.width/2) {
                gameOver();
                return;
            }

            // Remove enemies that go off screen
            if (enemy.y > canvas.height) {
                enemies.splice(index, 1);
            }
        });

        // Spawn new enemies
        if (Math.random() < 0.02) {
            enemies.push({
                x: Math.random() * (canvas.width - 30),
                y: -30,
                width: 30,
                height: 30,
                speed: 2 + score / 100
            });
        }

        // Add boss enemy
        if (score > 0 && score % 100 === 0) {
            enemies.push({ x: 100, y: -60, width: 60, height: 60, speed: 1, boss: true });
        }
        // In draw, if (enemy.boss) { ctx.fillStyle = '#FFD700'; }

        requestAnimationFrame(draw);
    }

    function shoot() {
        if (!gameActive) return;
        bullets.push({
            x: player.x,
            y: player.y
        });

        // Play shoot sound
        const shootSound = new Howl({
            src: ['sounds/shoot.mp3']
        });
        shootSound.play();
    }

    function gameOver() {
        gameActive = false;
        // Save score to leaderboard
        try {
            // Try to get the leaderboard module
            const leaderboardModule = window.leaderboardModule;
            if (leaderboardModule) {
                leaderboardModule.saveScore('Space Shooter', score);
            } else {
                // If module not loaded yet, try to load it
                import('./leaderboard.js').then(module => {
                    // Store the module for future use
                    window.leaderboardModule = module;
                    module.saveScore('Space Shooter', score);
                }).catch(error => {
                    console.error('Failed to save score:', error);
                });
            }
        } catch (error) {
            console.error('Failed to save score:', error);
        }
        
        gameOver.querySelector('.game-over-message').textContent = `Game Over! Score: ${score}`;
        gameOver.classList.add('visible');
        
        // Play game over sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    function updateScore() {
        const scoreElement = scoreBoard.querySelector('.score');
        const oldScore = parseInt(scoreElement.textContent.split(':')[1]);
        
        // Animate score change
        requestAnimationFrame(() => {
            let currentScore = oldScore;
            const step = Math.ceil((score - oldScore) / 10);
            
            function animateScore() {
                if (currentScore < score) {
                    currentScore += step;
                    if (currentScore > score) currentScore = score;
                    scoreElement.textContent = `Score: ${currentScore}`;
                    requestAnimationFrame(animateScore);
                } else {
                    scoreElement.textContent = `Score: ${score}`;
                }
            }
            animateScore();
        });
    }

    function resetGame() {
        player.x = canvas.width / 2;
        bullets.length = 0;
        enemies.length = 0;
        score = 0;
        gameActive = true;
        updateScore();
        draw();
    }

    // Event listeners
    document.addEventListener('keydown', (e) => {
        if (!gameActive) return;

        switch(e.key) {
            case 'ArrowLeft':
                player.x -= player.speed;
                break;
            case 'ArrowRight':
                player.x += player.speed;
                break;
            case ' ':
                shoot();
                break;
        }

        // Keep player within bounds
        if (player.x < player.width/2) player.x = player.width/2;
        if (player.x > canvas.width - player.width/2) player.x = canvas.width - player.width/2;
    });

    gameControls.querySelector('.reset-button').addEventListener('click', resetGame);
    gameOver.querySelector('.play-again-button').addEventListener('click', () => {
        resetGame();
        gameOver.classList.remove('visible');
    });

    // Start game
    resetGame();
}
