export function init() {
    const gameContainer = document.querySelector('.game-container');
    const scoreBoard = document.querySelector('.score-board');
    const gameControls = document.querySelector('.game-controls');
    const gameOver = document.querySelector('.game-over');

    const cards = [
        'apple', 'banana', 'orange', 'grape',
        'apple', 'banana', 'orange', 'grape',
        'strawberry', 'pineapple', 'kiwi', 'mango',
        'strawberry', 'pineapple', 'kiwi', 'mango'
    ];

    let firstCard = null;
    let secondCard = null;
    let moves = 0;
    let matches = 0;
    let gameActive = true;

    function createBoard() {
        const board = document.createElement('div');
        board.className = 'memory-board';

        const shuffledCards = shuffleArray([...cards]);

        shuffledCards.forEach(card => {
            const cardElement = document.createElement('div');
            cardElement.className = 'memory-card';
            cardElement.dataset.card = card;
            cardElement.innerHTML = `
                <div class="card-front"></div>
                <div class="card-back"><i class="fas fa-${card}"></i></div>
            `;
            cardElement.addEventListener('click', handleCardClick);
            board.appendChild(cardElement);
        });

        gameContainer.innerHTML = '';
        gameContainer.appendChild(board);
        resetGame();
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function handleCardClick(e) {
        if (!gameActive || e.target.classList.contains('flipped') || e.target.classList.contains('matched')) return;

        const card = e.target.closest('.memory-card');
        card.classList.add('flipped');

        if (!firstCard) {
            firstCard = card;
            return;
        }

        secondCard = card;
        moves++;
        updateScore();

        if (firstCard.dataset.card === secondCard.dataset.card) {
            setTimeout(() => {
                firstCard.classList.add('matched');
                secondCard.classList.add('matched');
                matches++;
                checkWin();
            }, 1000);
        } else {
            setTimeout(() => {
                firstCard.classList.remove('flipped');
                secondCard.classList.remove('flipped');
            }, 1000);
        }

        firstCard = null;
        secondCard = null;
    }

    function checkWin() {
        if (matches === cards.length / 2) {
            gameActive = false;
            showGameOver();
        }
    }

    function showGameOver() {
        gameOver.querySelector('.game-over-message').textContent = `Congratulations! You won in ${moves} moves!`;
        gameOver.classList.add('visible');
        
        // Play sound
        const winSound = new Howl({
            src: ['sounds/win.mp3']
        });
        winSound.play();
    }

    function updateScore() {
        scoreBoard.querySelector('.moves').textContent = `Moves: ${moves}`;
        scoreBoard.querySelector('.matches').textContent = `Matches: ${matches}/${cards.length/2}`;
    }

    function resetGame() {
        moves = 0;
        matches = 0;
        gameActive = true;
        updateScore();
        const cards = gameContainer.querySelectorAll('.memory-card');
        cards.forEach(card => {
            card.classList.remove('flipped', 'matched');
        });
        shuffleArray([...cards]);
    }

    // Event listeners
    gameControls.querySelector('.reset-button').addEventListener('click', resetGame);
    gameControls.querySelector('.new-game-button').addEventListener('click', createBoard);
    gameOver.querySelector('.play-again-button').addEventListener('click', () => {
        resetGame();
        gameOver.classList.remove('visible');
    });

    // Initialize game
    createBoard();
    // Add timer
    let timer = 0;
    let timerInterval;
    function startTimer() {
        timer = 0;
        timerInterval = setInterval(() => {
            timer++;
            document.querySelector('.timer').textContent = `Time: ${timer}s`;
        }, 1000);
    }
    function stopTimer() { clearInterval(timerInterval); }
    // Call startTimer() in createBoard, stopTimer() in showGameOver
}
