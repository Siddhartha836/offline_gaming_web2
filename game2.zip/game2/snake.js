export function init() {
    const canvas = document.querySelector('canvas');
    const ctx = canvas.getContext('2d');
    const gameControls = document.querySelector('.game-controls');
    const scoreBoard = document.querySelector('.score-board');
    const gameOver = document.querySelector('.game-over');

    const gridSize = 20;
    const tileCount = 20;
    canvas.width = tileCount * gridSize;
    canvas.height = tileCount * gridSize;

    let snake = [{
        x: 10,
        y: 10
    }];
    let food = {
        x: 5,
        y: 5
    };
    let dx = 0;
    let dy = 0;
    let score = 0;
    let gameActive = true;

    function draw() {
        if (!gameActive) return;

        // Clear canvas
        ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw food
        ctx.fillStyle = '#ff4444';
        ctx.fillRect(food.x * gridSize, food.y * gridSize, gridSize - 2, gridSize - 2);

        // Update snake position
        const head = { x: snake[0].x + dx, y: snake[0].y + dy };
        snake.unshift(head);

        // Check for food collision
        if (head.x === food.x && head.y === food.y) {
            score += 10;
            updateScore();
            generateFood();
        } else {
            snake.pop();
        }

        // Check for wall collision
        if (head.x < 0 || head.x >= tileCount || head.y < 0 || head.y >= tileCount) {
            gameOver();
            return;
        }

        // Check for self collision
        for (let i = 1; i < snake.length; i++) {
            if (head.x === snake[i].x && head.y === snake[i].y) {
                gameOver();
                return;
            }
        }

        // Draw snake
        ctx.fillStyle = '#4CAF50';
        snake.forEach((segment, index) => {
            ctx.fillRect(segment.x * gridSize, segment.y * gridSize, gridSize - 2, gridSize - 2);
        });

        requestAnimationFrame(draw);
    }

    // Add special food
    function generateFood() {
        food.x = Math.floor(Math.random() * tileCount);
        food.y = Math.floor(Math.random() * tileCount);
        food.special = Math.random() < 0.2;
    }
    // In draw, if (head.x === food.x && head.y === food.y) {
    //   if (food.special) score += 30; else score += 10;
    // }

    function gameOver() {
        gameActive = false;
        gameOver.querySelector('.game-over-message').textContent = `Game Over! Score: ${score}`;
        gameOver.classList.add('visible');
        
        // Play sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    function updateScore() {
        scoreBoard.querySelector('.score').textContent = `Score: ${score}`;
    }

    function resetGame() {
        snake = [{ x: 10, y: 10 }];
        dx = 0;
        dy = 0;
        score = 0;
        gameActive = true;
        updateScore();
        generateFood();
        draw();
    }

    // Event listeners
    document.addEventListener('keydown', (e) => {
        if (!gameActive) return;

        switch(e.key) {
            case 'ArrowUp':
                if (dy === 0) { dy = -1; dx = 0; }
                break;
            case 'ArrowDown':
                if (dy === 0) { dy = 1; dx = 0; }
                break;
            case 'ArrowLeft':
                if (dx === 0) { dx = -1; dy = 0; }
                break;
            case 'ArrowRight':
                if (dx === 0) { dx = 1; dy = 0; }
                break;
        }
    });

    gameControls.querySelector('.reset-button').addEventListener('click', resetGame);
    gameOver.querySelector('.play-again-button').addEventListener('click', () => {
        resetGame();
        gameOver.classList.remove('visible');
    });

    // Start game
    resetGame();
}
