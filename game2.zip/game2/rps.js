export function init() {
    const choices = document.querySelectorAll('.choice');
    const result = document.getElementById('result');
    const playerScore = document.getElementById('playerScore');
    const computerScore = document.getElementById('computerScore');
    const gameOver = document.querySelector('.game-over');
    const resetButton = document.querySelector('.reset-button');
    const finalScore = document.querySelector('.final-score');

    let playerWins = 0;
    let computerWins = 0;
    let gameActive = true;
    let currentChoice = null;

    function setupGame() {
        playerWins = 0;
        computerWins = 0;
        gameActive = true;
        updateScores();
        result.textContent = '';
        choices.forEach(choice => {
            choice.classList.remove('selected');
            choice.style.pointerEvents = 'auto';
        });
        gameOver.classList.remove('visible');
    }

    function handleChoice(choice) {
        if (!gameActive) return;
        
        currentChoice = choice.dataset.choice;
        choices.forEach(c => c.classList.remove('selected'));
        choice.classList.add('selected');
        
        // Play choice sound
        const choiceSound = new Howl({
            src: ['sounds/choice.mp3']
        });
        choiceSound.play();
        
        // Disable choices while computer makes its move
        choices.forEach(c => c.style.pointerEvents = 'none');
        
        // Simulate computer thinking
        setTimeout(() => {
            makeComputerMove();
        }, 1000);
    }

    function makeComputerMove() {
        const computerChoice = Math.floor(Math.random() * 3);
        const choices = ['rock', 'paper', 'scissors'];
        const computerMove = choices[computerChoice];
        
        // Play computer move sound
        const computerSound = new Howl({
            src: ['sounds/computer.mp3']
        });
        computerSound.play();
        
        // Determine winner
        const resultText = determineWinner(currentChoice, computerMove);
        result.textContent = resultText;
        
        // Update scores
        if (resultText.includes('Win')) {
            playerWins++;
            // Play win sound
            const winSound = new Howl({
                src: ['sounds/win.mp3']
            });
            winSound.play();
        } else if (resultText.includes('Lose')) {
            computerWins++;
            // Play lose sound
            const loseSound = new Howl({
                src: ['sounds/lose.mp3']
            });
            loseSound.play();
        }
        
        updateScores();
        
        // Check for game over
        if (playerWins >= 3 || computerWins >= 3) {
            gameOverGame();
        } else {
            // Re-enable choices
            choices.forEach(c => c.style.pointerEvents = 'auto');
        }
    }

    function determineWinner(player, computer) {
        if (player === computer) {
            return 'Draw!';
        }
        
        const rules = {
            rock: 'scissors',
            paper: 'rock',
            scissors: 'paper'
        };
        
        if (rules[player] === computer) {
            return `You Win! ${player.charAt(0).toUpperCase() + player.slice(1)} beats ${computer}`;
        } else {
            return `You Lose! ${computer.charAt(0).toUpperCase() + computer.slice(1)} beats ${player}`;
        }
    }

    function updateScores() {
        playerScore.textContent = playerWins;
        computerScore.textContent = computerWins;
        finalScore.textContent = playerWins;
    }

    function gameOverGame() {
        gameActive = false;
        gameOver.classList.add('visible');
        
        // Play game over sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    // Event listeners
    choices.forEach(choice => {
        choice.addEventListener('click', () => handleChoice(choice));
        // Add animation to choices
        choice.classList.add('animate-choice');
        setTimeout(() => choice.classList.remove('animate-choice'), 500);
    });

    resetButton.addEventListener('click', () => {
        setupGame();
    });

    // Initialize game
    setupGame();
}
