export function init() {
    const gameArea = document.querySelector('.game-area');
    const car = document.querySelector('.car');
    const scoreBoard = document.querySelector('.score-board');
    const gameOver = document.querySelector('.game-over');
    const resetButton = document.querySelector('.reset-button');
    const finalScore = document.querySelector('.final-score');

    let gameActive = true;
    let score = 0;
    let obstacleInterval;
    let obstacles = [];
    let speed = 2;
    let carSpeed = 5;
    let lastObstacleTime = 0;
    let obstacleFrequency = 1000;

    function setupGame() {
        score = 0;
        gameActive = true;
        speed = 2;
        obstacleFrequency = 1000;
        updateScore();
        
        // Reset car position
        car.style.left = '50%';
        car.style.transform = 'translateX(-50%)';
        
        // Clear existing obstacles
        obstacles.forEach(obstacle => {
            obstacle.element.remove();
        });
        obstacles = [];
        
        // Start game loop
        startGameLoop();
    }

    function startGameLoop() {
        // Start obstacle creation
        obstacleInterval = setInterval(createObstacle, obstacleFrequency);
        
        // Start score counter
        const scoreInterval = setInterval(() => {
            if (!gameActive) return;
            score++;
            updateScore();
            
            // Increase speed and difficulty
            if (score % 10 === 0) {
                speed += 0.2;
                obstacleFrequency = Math.max(500, obstacleFrequency - 50);
            }
        }, 1000);
    }

    function createObstacle() {
        if (!gameActive) return;
        
        const obstacle = document.createElement('div');
        obstacle.className = 'obstacle';
        
        // Random position for obstacle
        const position = Math.random() * (gameArea.offsetWidth - obstacle.offsetWidth);
        obstacle.style.left = position + 'px';
        
        gameArea.appendChild(obstacle);
        
        obstacles.push({
            element: obstacle,
            x: position,
            y: 0
        });
    }

    function updateGame() {
        if (!gameActive) return;
        
        // Update obstacles
        obstacles.forEach((obstacle, index) => {
            obstacle.y += speed;
            obstacle.element.style.bottom = obstacle.y + 'px';
            
            // Check if obstacle is off screen
            if (obstacle.y > gameArea.offsetHeight) {
                obstacle.element.remove();
                obstacles.splice(index, 1);
            }
            
            // Check collision
            if (checkCollision(obstacle)) {
                gameOver();
            }
        });
        
        requestAnimationFrame(updateGame);
    }

    function checkCollision(obstacle) {
        const carRect = car.getBoundingClientRect();
        const obstacleRect = obstacle.element.getBoundingClientRect();
        
        return carRect.left < obstacleRect.right &&
               carRect.right > obstacleRect.left &&
               carRect.top < obstacleRect.bottom &&
               carRect.bottom > obstacleRect.top;
    }

    function handleCarMovement(e) {
        if (!gameActive) return;
        
        const rect = gameArea.getBoundingClientRect();
        const x = e.clientX - rect.left;
        
        // Keep car within bounds
        if (x >= 0 && x <= rect.width - car.offsetWidth) {
            car.style.left = x + 'px';
        }
    }

    function updateScore() {
        scoreBoard.textContent = `Score: ${score}`;
        finalScore.textContent = score;
    }

    function gameOver() {
        gameActive = false;
        clearInterval(obstacleInterval);
        gameOver.classList.add('visible');
        
        // Play game over sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    // Event listeners
    gameArea.addEventListener('mousemove', handleCarMovement);
    resetButton.addEventListener('click', () => {
        setupGame();
    });

    // Initialize game
    setupGame();
    updateGame();
    // Add car model selection
    const carModels = ['car1.png', 'car2.png'];
    let currentCar = 0;
    function changeCar() {
        currentCar = (currentCar + 1) % carModels.length;
        car.style.backgroundImage = `url('images/${carModels[currentCar]}')`;
    }
    const carBtn = document.createElement('button');
    carBtn.textContent = 'Change Car';
    carBtn.onclick = changeCar;
    gameArea.appendChild(carBtn);
}
