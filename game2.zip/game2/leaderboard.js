let scores = JSON.parse(localStorage.getItem('gameScores') || '{}');

const loadLeaderboard = () => {
    const scores = JSON.parse(localStorage.getItem('gameScores') || '{}');
    const leaderboard = document.querySelector('.leaderboard');
    let html = '<h3>Top Scores</h3>';

    if (Object.keys(scores).length === 0) {
        html += '<p>No scores yet!</p>';
    } else {
        Object.entries(scores).forEach(([game, gameScores]) => {
            html += `<div class="leaderboard-section">`;
            html += `<h4>${game}</h4>`;
            html += '<div class="leaderboard-items">';

            // Sort scores by date (newest first)
            gameScores.sort((a, b) => new Date(b.date) - new Date(a.date));

            gameScores.forEach((score, index) => {
                html += `
                    <div class="leaderboard-item">
                        <span>${index + 1}. ${score.score}</span>
                        <span>${new Date(score.date).toLocaleDateString()}</span>
                    </div>
                `;
            });

            html += '</div></div>';
        });
    }

    leaderboard.innerHTML = html;
};

export function init() {
    const leaderboard = document.querySelector('.leaderboard');
    const gameControls = document.querySelector('.game-controls');
    const scoreBoard = document.querySelector('.score-board');

    // Event listeners
    gameControls.querySelector('.reset-button').addEventListener('click', () => {
        localStorage.removeItem('gameScores');
        loadLeaderboard();
    });

    // Initialize leaderboard
    loadLeaderboard();
}

export function saveScore(game, score) {
    scores[game] = scores[game] || [];
    scores[game].push({
        score: score,
        date: new Date().toISOString()
    });
    localStorage.setItem('gameScores', JSON.stringify(scores));
    loadLeaderboard();
}
