export function init() {
    const gameArea = document.querySelector('.game-area');
    const paddle = document.querySelector('.paddle');
    const ball = document.querySelector('.ball');
    const scoreBoard = document.querySelector('.score-board');
    const gameOver = document.querySelector('.game-over');
    const resetButton = document.querySelector('.reset-button');
    const finalScore = document.querySelector('.final-score');
    const startButton = document.createElement('button');
    startButton.className = 'start-button';
    startButton.textContent = 'Click to Start';
    startButton.style.position = 'absolute';
    startButton.style.top = '50%';
    startButton.style.left = '50%';
    startButton.style.transform = 'translate(-50%, -50%)';
    startButton.style.zIndex = '1000';
    gameArea.appendChild(startButton);

    let gameActive = false;
    let score = 0;
    let paddleSpeed = 5;
    let ballSpeedX = 2;
    let ballSpeedY = -2;
    let bricks = [];
    let powerUps = [];
    let lives = 3;

    function setupGame() {
        score = 0;
        lives = 3;
        gameActive = true;
        updateScore();
        
        // Reset paddle position
        paddle.style.left = (gameArea.offsetWidth - paddle.offsetWidth) / 2 + 'px';
        
        // Reset ball position and speed
        ball.style.left = (gameArea.offsetWidth - ball.offsetWidth) / 2 + 'px';
        ball.style.top = (gameArea.offsetHeight - ball.offsetHeight - paddle.offsetHeight - 10) + 'px';
        ballSpeedX = 2;
        ballSpeedY = -2;
        
        // Clear existing bricks and power-ups
        const brickElements = document.querySelectorAll('.brick');
        brickElements.forEach(brick => brick.remove());
        
        const powerUpElements = document.querySelectorAll('.power-up');
        powerUpElements.forEach(powerUp => powerUp.remove());
        
        // Create bricks
        createBricks();
        
        // Remove start button
        startButton.style.display = 'none';
        
        // Start game loop
        gameLoop();
    }

    function createBricks() {
        const rows = 5;
        const cols = 10;
        const brickWidth = 60;
        const brickHeight = 30;
        const spacing = 10;
        
        let x = spacing;
        let y = spacing;
        
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const brick = document.createElement('div');
                brick.className = 'brick';
                brick.style.left = x + 'px';
                brick.style.top = y + 'px';
                gameArea.appendChild(brick);
                bricks.push({
                    element: brick,
                    x: x,
                    y: y,
                    destroyed: false,
                    strength: 2 // Each brick needs to be hit twice
                });
                x += brickWidth + spacing;
            }
            x = spacing;
            y += brickHeight + spacing;
        }
    }

    function updateBall() {
        const ballRect = ball.getBoundingClientRect();
        const paddleRect = paddle.getBoundingClientRect();
        
        // Update ball position
        ball.style.left = (ballRect.left + ballSpeedX) + 'px';
        ball.style.top = (ballRect.top + ballSpeedY) + 'px';
        
        // Check wall collisions
        if (ballRect.left <= gameArea.offsetLeft || 
            ballRect.right >= gameArea.offsetLeft + gameArea.offsetWidth) {
            ballSpeedX = -ballSpeedX;
            
            // Play wall hit sound
            const hitSound = new Howl({
                src: ['sounds/hit.mp3']
            });
            hitSound.play();
        }
        
        if (ballRect.top <= gameArea.offsetTop) {
            ballSpeedY = -ballSpeedY;
            
            // Play ceiling hit sound
            const hitSound = new Howl({
                src: ['sounds/hit.mp3']
            });
            hitSound.play();
        }
        
        // Check paddle collision
        if (ballRect.bottom >= paddleRect.top &&
            ballRect.left < paddleRect.right &&
            ballRect.right > paddleRect.left) {
            ballSpeedY = -ballSpeedY;
            
            // Change ball direction based on where it hits the paddle
            const center = paddleRect.left + paddleRect.width / 2;
            const difference = (ballRect.left + ballRect.width / 2) - center;
            ballSpeedX = difference * 0.1;
            
            // Play paddle hit sound
            const hitSound = new Howl({
                src: ['sounds/hit.mp3']
            });
            hitSound.play();
        }
        
        // Check brick collisions
        bricks.forEach((brick, index) => {
            if (!brick.destroyed) {
                const brickRect = brick.element.getBoundingClientRect();
                
                if (ballRect.left < brickRect.right &&
                    ballRect.right > brickRect.left &&
                    ballRect.top < brickRect.bottom &&
                    ballRect.bottom > brickRect.top) {
                    
                    brick.strength--;
                    if (brick.strength <= 0) {
                        brick.destroyed = true;
                        brick.element.remove();
                        score += 10;
                        
                        // Play brick break sound
                        const breakSound = new Howl({
                            src: ['sounds/break.mp3']
                        });
                        breakSound.play();
                        
                        // Random chance for power-up
                        if (Math.random() < 0.2) {
                            createPowerUp(brick.x, brick.y + brickHeight);
                        }
                    }
                    
                    // Change ball direction based on where it hits the brick
                    const ballCenter = ballRect.left + ballRect.width / 2;
                    const brickCenter = brickRect.left + brickRect.width / 2;
                    
                    if (Math.abs(ballCenter - brickCenter) > 10) {
                        ballSpeedX = -ballSpeedX;
                    } else {
                        ballSpeedY = -ballSpeedY;
                    }
                }
            }
        });
        
        // Check power-up collisions
        powerUps.forEach((powerUp, index) => {
            const powerUpRect = powerUp.element.getBoundingClientRect();
            
            if (powerUpRect.bottom >= paddleRect.top &&
                powerUpRect.left < paddleRect.right &&
                powerUpRect.right > paddleRect.left) {
                
                applyPowerUp(powerUp.type);
                powerUp.element.remove();
                powerUps.splice(index, 1);
            }
        });
        
        // Check game over
        if (ballRect.bottom >= gameArea.offsetHeight) {
            lives--;
            if (lives <= 0) {
                gameOver();
            } else {
                // Reset ball position
                ball.style.left = (gameArea.offsetWidth - ball.offsetWidth) / 2 + 'px';
                ball.style.top = (gameArea.offsetHeight - ball.offsetHeight - paddle.offsetHeight - 10) + 'px';
                ballSpeedX = 2;
                ballSpeedY = -2;
            }
        }
    }

    function updatePaddle() {
        const paddleRect = paddle.getBoundingClientRect();
        
        // Update paddle position based on mouse
        gameArea.addEventListener('mousemove', (e) => {
            const rect = gameArea.getBoundingClientRect();
            const x = e.clientX - rect.left - paddle.offsetWidth / 2;
            
            if (x >= 0 && x <= rect.width - paddle.offsetWidth) {
                paddle.style.left = x + 'px';
            }
        });
    }

    // Add power-up logic inside createBricks and updateBall
    function createPowerUp(x, y) {
        const powerUp = document.createElement('div');
        powerUp.className = 'power-up';
        powerUp.style.left = x + 'px';
        powerUp.style.top = y + 'px';
        gameArea.appendChild(powerUp);
        powerUps.push({ element: powerUp, x, y, type: 'expand' });
    }
    function applyPowerUp(type) {
        if (type === 'expand') {
            paddle.style.width = '160px';
            setTimeout(() => { paddle.style.width = '100px'; }, 5000);
        }
        // Add more power-up types as needed
    }

    function updateScore() {
        scoreBoard.textContent = `Score: ${score} | Lives: ${lives}`;
        finalScore.textContent = score;
    }

    function gameOver() {
        gameActive = false;
        gameOver.classList.add('visible');
        
        // Play game over sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    function gameLoop() {
        if (!gameActive) return;
        
        updateBall();
        requestAnimationFrame(gameLoop);
    }

    // Event listeners
    document.addEventListener('click', (e) => {
        if (!gameActive) {
            setupGame();
            return;
        }
    });

    // Mobile touch support
    document.addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (!gameActive) {
            setupGame();
            return;
        }
    });

    resetButton.addEventListener('click', () => {
        setupGame();
    });

    // Initialize game
    gameArea.style.cursor = 'pointer';
    startButton.addEventListener('click', () => {
        setupGame();
    });
}
