export function init() {
    const gameArea = document.querySelector('.game-area');
    const scoreBoard = document.querySelector('.score-board');
    const timerElement = document.querySelector('.timer');
    const gameOver = document.querySelector('.game-over');
    const resetButton = document.querySelector('.reset-button');
    const finalScore = document.querySelector('.final-score');
    const startButton = document.createElement('button');
    startButton.className = 'start-button';
    startButton.textContent = 'Click to Start';
    startButton.style.position = 'absolute';
    startButton.style.top = '50%';
    startButton.style.left = '50%';
    startButton.style.transform = 'translate(-50%, -50%)';
    startButton.style.zIndex = '1000';
    gameArea.appendChild(startButton);

    let gameActive = false;
    let score = 0;
    let timeLeft = 30;
    let moleInterval;
    let timerInterval;
    let lastMoleTime = 0;
    let moleFrequency = 1000;
    let moleCount = 0;
    let maxMoles = 3;
    let bonusActive = false;

    function setupGame() {
        score = 0;
        timeLeft = 30;
        moleCount = 0;
        gameActive = true;
        updateScore();
        updateTimer();
        
        // Clear existing holes and moles
        gameArea.innerHTML = '';
        
        // Create holes
        for (let i = 0; i < 9; i++) {
            const hole = document.createElement('div');
            hole.className = 'hole';
            hole.addEventListener('click', handleMoleClick);
            gameArea.appendChild(hole);
        }
        
        // Remove start button
        startButton.style.display = 'none';
        
        // Start game
        startGameLoop();
    }

    function startGameLoop() {
        // Start mole appearing interval
        moleInterval = setInterval(() => {
            if (!gameActive) return;
            showRandomMole();
        }, moleFrequency);

        // Start timer
        timerInterval = setInterval(() => {
            if (!gameActive) return;
            timeLeft--;
            updateTimer();
            
            if (timeLeft <= 0) {
                gameOver();
            }
        }, 1000);
    }

    function showRandomMole() {
        const holes = document.querySelectorAll('.hole');
        const randomHole = holes[Math.floor(Math.random() * holes.length)];
        const mole = randomHole.querySelector('.mole');
        
        // Limit number of moles at once
        if (moleCount >= maxMoles) return;
        
        // Remove existing mole if any
        if (mole) mole.remove();
        
        // Create new mole
        const newMole = document.createElement('div');
        newMole.className = 'mole';
        newMole.style.display = 'block';
        
        // Set random time for mole to appear (now shorter)
        const time = Math.random() * 800 + 300;
        
        // Add animation class
        newMole.classList.add('mole-animation');
        
        // Set mole to disappear
        setTimeout(() => {
            newMole.style.display = 'none';
            moleCount--;
        }, time);
        
        // Track mole count
        moleCount++;
        
        randomHole.appendChild(newMole);
    }

    function handleMoleClick(e) {
        if (!gameActive) return;
        
        const mole = e.target.querySelector('.mole');
        if (mole && mole.style.display === 'block') {
            // Calculate score based on time remaining and difficulty
            const baseScore = Math.ceil(30 - timeLeft);
            const difficultyBonus = Math.floor(moleCount / 2);
            score += baseScore + difficultyBonus;
            updateScore();
            
            // Play hit sound
            const hitSound = new Howl({
                src: ['sounds/hit.mp3']
            });
            hitSound.play();
        } else {
            // Play miss sound
            const missSound = new Howl({
                src: ['sounds/miss.mp3']
            });
            missSound.play();
        }
        
        // Add bonus round
        if (score > 50 && !bonusActive) {
            maxMoles = 5;
            moleFrequency = 700;
            bonusActive = true;
        }
    }

    function updateScore() {
        scoreBoard.textContent = `Score: ${score}`;
        finalScore.textContent = score;
    }

    function updateTimer() {
        timerElement.textContent = `Time: ${timeLeft}s`;
    }

    function gameOver() {
        gameActive = false;
        clearInterval(moleInterval);
        clearInterval(timerInterval);
        gameOver.classList.add('visible');
        
        // Play game over sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    // Event listeners
    document.addEventListener('click', (e) => {
        if (!gameActive) {
            setupGame();
            return;
        }
    });

    // Mobile touch support
    document.addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (!gameActive) {
            setupGame();
            return;
        }
    });

    resetButton.addEventListener('click', () => {
        setupGame();
    });

    // Initialize game
    gameArea.style.cursor = 'pointer';
    startButton.addEventListener('click', () => {
        setupGame();
    });
}
