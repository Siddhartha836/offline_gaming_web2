export function init() {
    const gameArea = document.querySelector('.game-area');
    const bird = document.querySelector('.bird');
    const scoreBoard = document.querySelector('.score-board');
    const gameOver = document.querySelector('.game-over');
    const resetButton = document.querySelector('.reset-button');
    const finalScore = document.querySelector('.final-score');
    const startButton = document.createElement('button');
    startButton.className = 'start-button';
    startButton.textContent = 'Tap to Start';
    startButton.style.position = 'absolute';
    startButton.style.top = '50%';
    startButton.style.left = '50%';
    startButton.style.transform = 'translate(-50%, -50%)';
    startButton.style.zIndex = '1000';
    gameArea.appendChild(startButton);

    let gameActive = false;
    let score = 0;
    let gravity = 0.5;
    let velocity = 0;
    let pipeSpeed = 2;
    let pipeGap = 150;
    let pipeWidth = 60;
    let pipeHeight = 300;
    let pipes = [];
    let lastPipeTime = 0;
    let pipeFrequency = 1500;

    function setupGame() {
        score = 0;
        velocity = 0;
        gameActive = true;
        pipes = [];
        updateScore();
        
        // Reset bird position
        bird.style.top = '50%';
        bird.style.left = '50%';
        
        // Remove existing pipes
        const pipeElements = document.querySelectorAll('.pipe');
        pipeElements.forEach(pipe => pipe.remove());
        
        // Remove start button
        startButton.style.display = 'none';
        
        // Start game loop
        gameLoop();
    }

    function createPipes() {
        const now = Date.now();
        if (now - lastPipeTime < pipeFrequency) return;
        
        const topPipe = document.createElement('div');
        const bottomPipe = document.createElement('div');
        
        topPipe.className = 'pipe top';
        bottomPipe.className = 'pipe bottom';
        
        // Random height with minimum gap
        const height = Math.random() * (gameArea.offsetHeight - pipeGap - 100) + 50;
        
        topPipe.style.height = height + 'px';
        bottomPipe.style.height = gameArea.offsetHeight - height - pipeGap + 'px';
        
        gameArea.appendChild(topPipe);
        gameArea.appendChild(bottomPipe);
        
        pipes.push({
            top: topPipe,
            bottom: bottomPipe,
            x: gameArea.offsetWidth,
            scored: false
        });
        
        lastPipeTime = now;
    }

    function updatePipes() {
        pipes.forEach(pipe => {
            pipe.x -= pipeSpeed;
            
            pipe.top.style.left = pipe.x + 'px';
            pipe.bottom.style.left = pipe.x + 'px';
            
            // Check if pipe is off screen
            if (pipe.x + pipeWidth < 0) {
                pipe.top.remove();
                pipe.bottom.remove();
                pipes.shift();
            }
            
            // Check if player has passed pipe
            if (!pipe.scored && pipe.x + pipeWidth < bird.offsetLeft) {
                pipe.scored = true;
                score++;
                updateScore();
                
                // Play score sound
                const scoreSound = new Howl({
                    src: ['sounds/score.mp3']
                });
                scoreSound.play();
            }
        });
    }

    function updateBird() {
        velocity += gravity;
        bird.style.top = (bird.offsetTop + velocity) + 'px';
        
        // Check for collisions
        if (checkCollision()) {
            gameOver();
        }
    }

    function checkCollision() {
        // Check top collision
        if (bird.offsetTop < 0) {
            return true;
        }
        
        // Check bottom collision
        if (bird.offsetTop > gameArea.offsetHeight - bird.offsetHeight) {
            return true;
        }
        
        // Check pipe collision
        pipes.forEach(pipe => {
            if (bird.offsetLeft < pipe.x + pipeWidth && 
                bird.offsetLeft + bird.offsetWidth > pipe.x && 
                (bird.offsetTop < pipe.top.offsetHeight || 
                 bird.offsetTop + bird.offsetHeight > gameArea.offsetHeight - pipe.bottom.offsetHeight)) {
                return true;
            }
        });
        
        return false;
    }

    function updateScore() {
        scoreBoard.textContent = `Score: ${score}`;
        finalScore.textContent = score;
    }

    function gameOver() {
        gameActive = false;
        gameOver.classList.add('visible');
        
        // Play game over sound
        const gameOverSound = new Howl({
            src: ['sounds/gameover.mp3']
        });
        gameOverSound.play();
    }

    function gameLoop() {
        if (!gameActive) return;
        
        createPipes();
        updateBird();
        updatePipes();
        
        requestAnimationFrame(gameLoop);
    }

    // Event listeners
    document.addEventListener('click', (e) => {
        if (!gameActive) {
            setupGame();
            return;
        }
        
        velocity = -10;
        
        // Play jump sound
        const jumpSound = new Howl({
            src: ['sounds/jump.mp3']
        });
        jumpSound.play();
    });

    // Mobile touch support
    document.addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (!gameActive) {
            setupGame();
            return;
        }
        
        velocity = -10;
        
        // Play jump sound
        const jumpSound = new Howl({
            src: ['sounds/jump.mp3']
        });
        jumpSound.play();
    });

    resetButton.addEventListener('click', () => {
        setupGame();
    });

    // Initialize game
    gameArea.style.cursor = 'pointer';
    startButton.addEventListener('click', () => {
        setupGame();
    });
    // Add bird skin selection
    const skins = ['bird1.png', 'bird2.png'];
    let currentSkin = 0;
    function changeSkin() {
        currentSkin = (currentSkin + 1) % skins.length;
        bird.style.backgroundImage = `url('images/${skins[currentSkin]}')`;
    }
    // Add a button to change skin
    const skinBtn = document.createElement('button');
    skinBtn.textContent = 'Change Bird Skin';
    skinBtn.onclick = changeSkin;
    gameArea.appendChild(skinBtn);
}
